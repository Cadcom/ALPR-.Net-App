using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using OpenCvSharp;

namespace ALPR.Detection
{
    public class TitanV8ModelResult
    {
        public string Text { get; set; } = string.Empty;
        public float Confidence { get; set; }

        /// <summary>"Slot" ya da "CTC" — hangi head seçildi.</summary>
        public string ModelHead { get; set; } = string.Empty;

        /// <summary>ALG6 karar nedeni — debug için faydalı.</summary>
        public string ChooserReason { get; set; } = string.Empty;

        public List<PlateCharDetail> Details { get; set; } = new List<PlateCharDetail>();

        public bool IsSecure => Details.Count > 0 && Details.All(x => x.Confidence >= TitanArmorV8Detector.SecureThreshold);
    }

    public class TitanArmorV8Detector : IDisposable
    {
        private readonly InferenceSession _session;

        // ── Model sabitleri ──────────────────────────────────────────────────────
        private const int ImgW = 128;
        private const int ImgH = 96;
        private const int MaxLabelLen = 16;

        // Slot head: VocabularyProjection → softmax → vocab_size sınıf
        private const int SlotVocab = 37;

        // CTC head: LogSoftmaxHead → log_softmax → vocab_size+1 sınıf, blank=son index
        private const int CtcVocab = 38;
        private const int CtcBlank = 37;

        private const int PadIdx = 0; // index 0 = boşluk / padding

        // ── Eşik değerleri ──────────────────────────────────────────────────────
        public const float SecureThreshold = 0.85f;

        // ALG6: "neither_secure" durumunda min_conf farkı eşiği
        private const float NeitherMinDiffThr = 0.09f;

        // ALG6: "char_multi" durumunda diff-pozisyon ortalaması farkı eşiği
        private const float CharMultiDiffThr = 0.05f;

        // ── Kelime dağarcığı ─────────────────────────────────────────────────────
        // İndeks 0 = pad (boşluk), 1-10 = rakamlar, 11-36 = harfler
        private const string Vocab = " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        // ── Dahili decode sonucu ─────────────────────────────────────────────────
        private sealed class DecodeResult
        {
            public string Text { get; init; } = string.Empty;
            public float AvgConf { get; init; }
            public float MinConf { get; init; }
            public bool IsSecure { get; init; }
            public bool InternalPad { get; init; }
            public IReadOnlyList<float> CharConfs { get; init; } = Array.Empty<float>();
            public List<PlateCharDetail> Details { get; init; } = new();
        }

        // ────────────────────────────────────────────────────────────────────────

        public TitanArmorV8Detector(string modelPath, bool useGpu = false)
        {
            var options = new SessionOptions
            {
                GraphOptimizationLevel = GraphOptimizationLevel.ORT_ENABLE_ALL
            };
            if (useGpu)
            {
                try { options.AppendExecutionProvider_CUDA(0); } catch { }
            }
            _session = new InferenceSession(modelPath, options);
        }

        public TitanV8ModelResult Predict(Mat inputMat)
        {
            var input = Preprocess(inputMat);

            using var inputVal = OrtValue.CreateTensorValueFromMemory(
                input, new long[] { 1, ImgH, ImgW, 1 });

            using var outputs = _session.Run(
                new RunOptions(),
                new Dictionary<string, OrtValue> { ["v8_image"] = inputVal },
                new[] { "slot_head", "ctc_head" });

            var slotSpan = outputs[0].GetTensorDataAsSpan<float>();
            var ctcSpan = outputs[1].GetTensorDataAsSpan<float>();
            int seqLen = (int)outputs[1].GetTensorTypeAndShape().Shape[1];

            var slot = DecodeSlot(slotSpan);
            var ctc = DecodeCTC(ctcSpan, seqLen);

            return ChoosePrediction(slot, ctc);
        }

        // ── Ön işlem ─────────────────────────────────────────────────────────────

        private float[] Preprocess(Mat img)
        {
            using var gray = new Mat();
            if (img.Channels() == 3)
                Cv2.CvtColor(img, gray, ColorConversionCodes.BGR2GRAY);
            else
                img.CopyTo(gray);

            using var clahed = new Mat();
            using var clahe = Cv2.CreateCLAHE(2.5, new OpenCvSharp.Size(8, 8));
            clahe.Apply(gray, clahed);

            double ratio = Math.Min((double)ImgW / clahed.Cols, (double)ImgH / clahed.Rows);
            int newW = Math.Max(1, (int)Math.Round(clahed.Cols * ratio));
            int newH = Math.Max(1, (int)Math.Round(clahed.Rows * ratio));

            var interp = ratio < 1.0 ? InterpolationFlags.Area : InterpolationFlags.Linear;
            using var resized = new Mat();
            Cv2.Resize(clahed, resized, new OpenCvSharp.Size(newW, newH), 0, 0, interp);

            int top = (ImgH - newH) / 2;
            int bottom = ImgH - newH - top;
            int left = (ImgW - newW) / 2;
            int right = ImgW - newW - left;

            using var padded = new Mat();
            Cv2.CopyMakeBorder(resized, padded, top, bottom, left, right,
                               BorderTypes.Constant, Scalar.Black);

            using var floatMat = new Mat();
            padded.ConvertTo(floatMat, MatType.CV_32FC1, 1.0 / 255.0);

            var tensor = new float[ImgH * ImgW];
            var indexer = floatMat.GetGenericIndexer<float>();
            int idx = 0;
            for (int y = 0; y < ImgH; y++)
                for (int x = 0; x < ImgW; x++)
                    tensor[idx++] = indexer[y, x];

            return tensor;
        }

        // ── Slot decode ──────────────────────────────────────────────────────────
        //
        // VocabularyProjection → activation="softmax"
        // Çıktı doğrudan olasılık [0,1], exp() GEREKMİYOR.
        // Shape: [1, MaxLabelLen, SlotVocab]
        //
        private DecodeResult DecodeSlot(ReadOnlySpan<float> data)
        {
            var ids = new int[MaxLabelLen];
            var tokenConf = new float[MaxLabelLen];

            for (int s = 0; s < MaxLabelLen; s++)
            {
                int bestIdx = 0;
                float bestProb = data[s * SlotVocab];
                for (int v = 1; v < SlotVocab; v++)
                {
                    float p = data[s * SlotVocab + v];
                    if (p > bestProb) { bestProb = p; bestIdx = v; }
                }
                ids[s] = bestIdx;
                tokenConf[s] = bestProb; // softmax → doğrudan olasılık
            }

            // İlk pad-olmayan token'ı bul
            int first = -1;
            for (int i = 0; i < MaxLabelLen; i++)
                if (ids[i] != PadIdx) { first = i; break; }

            if (first < 0)
            {
                return new DecodeResult
                {
                    Text = string.Empty,
                    AvgConf = 0f,
                    MinConf = 0f,
                    IsSecure = false,
                    InternalPad = false,
                    CharConfs = Array.Empty<float>(),
                    Details = new()
                };
            }

            // Metin bölgesinin sonunu (cutoff) bul ve internal_pad'i tespit et
            int cutoff = MaxLabelLen;
            bool internalPad = false;

            for (int i = first; i < MaxLabelLen; i++)
            {
                if (ids[i] == PadIdx)
                {
                    cutoff = i;
                    // cutoff'tan sonra pad-olmayan token var mı?
                    for (int j = i + 1; j < MaxLabelLen; j++)
                        if (ids[j] != PadIdx) { internalPad = true; break; }
                    break;
                }
            }

            var charConfs = new List<float>(cutoff - first);
            var details = new List<PlateCharDetail>(cutoff - first);
            var sb = new System.Text.StringBuilder(cutoff - first);

            for (int i = first; i < cutoff; i++)
            {
                char c = Vocab[ids[i]];
                float cf = tokenConf[i];
                sb.Append(c);
                charConfs.Add(cf);
                details.Add(new PlateCharDetail { Character = c, Confidence = cf });
            }

            float avgConf = charConfs.Count > 0 ? charConfs.Average() : 0f;
            float minConf = charConfs.Count > 0 ? charConfs.Min() : 0f;
            bool isSecure = charConfs.Count > 0 && charConfs.All(c => c >= SecureThreshold);

            return new DecodeResult
            {
                Text = sb.ToString(),
                AvgConf = avgConf,
                MinConf = minConf,
                IsSecure = isSecure,
                InternalPad = internalPad,
                CharConfs = charConfs,
                Details = details
            };
        }

        // ── CTC decode ───────────────────────────────────────────────────────────
        //
        // LogSoftmaxHead → log_softmax
        // exp() ZORUNLU, aksi takdirde confidence değerleri negatif olur.
        // Shape: [1, seqLen, CtcVocab], blank = CtcBlank = 37
        //
        private DecodeResult DecodeCTC(ReadOnlySpan<float> logData, int seqLen)
        {
            // log_softmax → softmax
            var probs = new float[seqLen * CtcVocab];
            for (int t = 0; t < seqLen; t++)
            {
                float sum = 0f;
                for (int v = 0; v < CtcVocab; v++)
                {
                    float p = MathF.Exp(logData[t * CtcVocab + v]);
                    probs[t * CtcVocab + v] = p;
                    sum += p;
                }
                float inv = 1f / MathF.Max(sum, 1e-8f);
                for (int v = 0; v < CtcVocab; v++) probs[t * CtcVocab + v] *= inv;
            }

            // Greedy best-path
            var path = new int[seqLen];
            for (int t = 0; t < seqLen; t++)
            {
                int bi = 0;
                float bp = probs[t * CtcVocab];
                for (int v = 1; v < CtcVocab; v++)
                {
                    if (probs[t * CtcVocab + v] > bp) { bp = probs[t * CtcVocab + v]; bi = v; }
                }
                path[t] = bi;
            }

            // CTC collapse: tekrar eden aynı token = tek token, blank atla
            var charConfs = new List<float>();
            var details = new List<PlateCharDetail>();
            var sb = new System.Text.StringBuilder();

            int pos = 0;
            while (pos < seqLen)
            {
                int idx = path[pos];
                if (idx == CtcBlank) { pos++; continue; }

                int start = pos;
                while (pos < seqLen && path[pos] == idx) pos++;

                // Bu token'ın span boyunca ortalama olasılığı
                float avg = 0f;
                for (int t = start; t < pos; t++) avg += probs[t * CtcVocab + idx];
                avg /= (pos - start);

                if (idx < Vocab.Length)
                {
                    char c = Vocab[idx];
                    sb.Append(c);
                    charConfs.Add(avg);
                    details.Add(new PlateCharDetail { Character = c, Confidence = avg });
                }
            }

            float avgConf = charConfs.Count > 0 ? charConfs.Average() : 0f;
            float minConf = charConfs.Count > 0 ? charConfs.Min() : 0f;
            bool isSecure = charConfs.Count > 0 && charConfs.All(c => c >= SecureThreshold);

            return new DecodeResult
            {
                Text = sb.ToString(),
                AvgConf = avgConf,
                MinConf = minConf,
                IsSecure = isSecure,
                InternalPad = false, // CTC'nin internal pad kavramı yok
                CharConfs = charConfs,
                Details = details
            };
        }

        // ── ALG6: choose_prediction ───────────────────────────────────────────────
        //
        // Python train_ocr.py → choose_prediction() ile birebir eşleştirilmiştir.
        // 44.330 örneklik audit analizine dayalı karar ağacı:
        //
        //   Adım 1: İkisi de boş
        //   Adım 2: Biri boş
        //   Adım 3: slot internal_pad → CTC daha güvenilir
        //   Adım 4: Metinler aynı → secure olana öncelik, eşitse slot
        //   Adım 5: Anlaşmazlık
        //     5a. Eşit uzunluk, char_confs mevcut:
        //         1 char farklı  → o pozisyonun conf'u karşılaştır
        //         2+ char farklı → diff pozisyonlar ort., fark >= 0.05 ise karar
        //     5b. Secure grubuna göre:
        //         only_slot_secure  → slot  (N=79,  net +57)
        //         both_secure       → conf_diff >= 0 → slot  (N=31)
        //         only_ctc_secure   → CTC   (N=170, net +128)
        //         neither_secure    → min_diff >= 0.09 → slot, değilse CTC  (N=325)
        //
        private static TitanV8ModelResult ChoosePrediction(DecodeResult slot, DecodeResult ctc)
        {
            bool slotEmpty = string.IsNullOrEmpty(slot.Text);
            bool ctcEmpty = string.IsNullOrEmpty(ctc.Text);

            // Adım 1: İkisi de boş
            if (slotEmpty && ctcEmpty)
                return MakeResult(slot, "both_empty", "Slot");

            // Adım 2: Biri boş
            if (slotEmpty) return MakeResult(ctc, "slot_empty", "CTC");
            if (ctcEmpty) return MakeResult(slot, "ctc_empty", "Slot");

            // Adım 3: slot internal_pad → CTC
            if (slot.InternalPad)
                return MakeResult(ctc, "slot_internal_pad", "CTC");

            // Adım 4: Aynı metin
            if (slot.Text == ctc.Text)
            {
                if (slot.IsSecure && !ctc.IsSecure) return MakeResult(slot, "agree_slot_secure", "Slot");
                if (ctc.IsSecure && !slot.IsSecure) return MakeResult(ctc, "agree_ctc_secure", "CTC");
                return MakeResult(slot, "agree_slot_default", "Slot");
            }

            // Adım 5: Anlaşmazlık
            float confDiff = slot.AvgConf - ctc.AvgConf;
            float minDiff = slot.MinConf - ctc.MinConf;

            // 5a. Eşit uzunluk ve char_confs mevcut → pozisyon bazlı karar
            if (slot.Text.Length == ctc.Text.Length
                && slot.CharConfs.Count == slot.Text.Length
                && ctc.CharConfs.Count == ctc.Text.Length
                && slot.Text.Length > 0)
            {
                var diffPos = new List<int>();
                for (int i = 0; i < slot.Text.Length; i++)
                    if (slot.Text[i] != ctc.Text[i]) diffPos.Add(i);

                if (diffPos.Count == 1)
                {
                    // Tam 1 char farklı: o pozisyonun conf'unu doğrudan karşılaştır
                    int i = diffPos[0];
                    float posConfDiff = slot.CharConfs[i] - ctc.CharConfs[i];
                    return posConfDiff >= 0f
                        ? MakeResult(slot, "disagree_char_pos_slot", "Slot")
                        : MakeResult(ctc, "disagree_char_pos_ctc", "CTC");
                }

                if (diffPos.Count >= 2)
                {
                    // 2+ char farklı: diff pozisyonların ortalama conf'unu karşılaştır
                    float slotDiffMean = (float)diffPos.Average(i => (double)slot.CharConfs[i]);
                    float ctcDiffMean = (float)diffPos.Average(i => (double)ctc.CharConfs[i]);
                    float diffPosGap = slotDiffMean - ctcDiffMean;

                    if (MathF.Abs(diffPosGap) >= CharMultiDiffThr)
                    {
                        return diffPosGap >= 0f
                            ? MakeResult(slot, "disagree_char_multi_slot", "Slot")
                            : MakeResult(ctc, "disagree_char_multi_ctc", "CTC");
                    }
                    // Fark belirsiz → 5b'ye düş
                }
            }

            // 5b. Secure grubu bazlı karar
            if (slot.IsSecure && !ctc.IsSecure)
                // only_slot_secure → slot (N=79, net +57)
                return MakeResult(slot, "disagree_slot_secure_only", "Slot");

            if (slot.IsSecure && ctc.IsSecure)
                // both_secure → conf_diff >= 0 ise slot (N=31)
                return confDiff >= 0f
                    ? MakeResult(slot, "disagree_both_secure_slot", "Slot")
                    : MakeResult(ctc, "disagree_both_secure_ctc", "CTC");

            if (!slot.IsSecure && ctc.IsSecure)
                // only_ctc_secure → CTC (N=170, net +128)
                return MakeResult(ctc, "disagree_ctc_secure_only", "CTC");

            // neither_secure → min_diff eşiği (N=325, thr=0.09 optimal)
            return minDiff >= NeitherMinDiffThr
                ? MakeResult(slot, "disagree_neither_slot_min", "Slot")
                : MakeResult(ctc, "disagree_ctc_default", "CTC");
        }

        private static TitanV8ModelResult MakeResult(DecodeResult src, string reason, string head)
        {
            return new TitanV8ModelResult
            {
                Text = src.Text,
                Confidence = src.AvgConf,
                ModelHead = head,
                ChooserReason = reason,
                Details = src.Details
            };
        }

        public void Dispose() => _session?.Dispose();
    }
}